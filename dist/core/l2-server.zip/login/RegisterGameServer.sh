#!/bin/sh
java -cp l2login.jar ru.l2gw.gsregistering.GameServerRegister
